#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.

#set -euo pipefail
#set -xv
source "variables.txt"
export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y_%m_%d_%H_%M)

NFS_LOGS=${NFS}LOGS
NFS_BAK_LOGS=${NFS}OLD_BAK_LOG_${DATE}

echo "REALLY REMOVE ALL? [Y,N]"
read input
if [[ $input == "Y" || $input == "y" ]]; then
	echo "REMOVING EVERYTHING, BACKING UP LOGS IF EXISTS"
	if ls -a .*.token 1> /dev/null 2>&1; then
		rm .*.token
	fi
	rm -rf ${NFS}BACKUP
	rm -rf ${NFS}IMPORTANT
	if [ -d "${NFS_LOGS}" ]; then
		cp -r ${NFS_LOGS} ${NFS_BAK_LOGS}
		rm -rf ${NFS}LOGS
		echo MOVED OLD LOGS DIR TO ${NFS}BAK_LOG_${DATE}	
		chmod -R 777 ${NFS_BAK_LOGS}
	fi

else
	echo "EXITING, NOTHING WILL BE DELETED"
        exit 1
fi

echo "DONE"
