#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.

# BREAKS MAINSCRIPT IF SUB FAILS, DONT COMMENT OR BAD THINGS HAPPEN
set -e

# DEBUG COMMENT OUT IF NOT DEBUGGING
set -o pipefail

# MEGA DEBUG COMMENT OUT IF NOT DEBUGGING
#set -xv


# CHECKING FOR WRITE PERMISSIONS
echo RUNNING WRITE TO FOLDER PERMISSION TEST FOR TOKENS
if touch .PASS.TOKEN 2> /dev/null; then
	echo "WRITE PERMISSION OK"
	rm .PASS.TOKEN
else
	echo "NO WRITE PERMISSION"
	echo "TRY CHMOD -R 777 WHOLE FOLDER FROM SOURCE"
	exit 22
fi


# DATE FORMAT
export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M)

echo
echo ==============================================================
echo VERIFYING VARIABLES.TXT EXISTS
echo ==============================================================
echo


if [ -f "variables.txt" ]; then
        echo "variables.txt exists, sourcing"
        source "variables.txt"
else
        echo "Error: variables.txt doesn't exist!"
        echo "Copying variables.template to variable.txt"
        cp ../.dontremove/template.variables.txt variables.txt
        chmod 777 variables.txt
        echo "Please fill out, exiting..."
        exit 2;
fi

if [[ ! -e ${NFS} ]]; then
        mkdir -m 777 ${NFS}
fi


export LOGS_DIR=${NFS}LOGS/
export log_file=${LOGS_DIR}RMAN_TRGT_RESTORE_OVERALL_${DATE}.log
exec > >(tee -a ${log_file} )
exec 2> >(tee -a ${log_file} >&2)
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/
echo spooling log to ${log_file}
echo "SCRIPT STARTING TIME -> "$(date -u)
sleep 1

# VERIFY SID / UNQ
#../.dontremove/trgt/trgt_oracle_env_check.sh

# TOKENS
if [ ! -e .rman_bak_done.token ]; then echo "SOURCE DATABASE WASN'T BACKED UP... YOU'RE GOING TO HAVE TO RESTART... EXITING"; exit 2; fi
if [ ! -e .src_control.token ]; then echo "SOURCE CONTROL FILE WASN'T BACKED UP... MANAULLY BACKUP ON SOURCE... EXITING"; exit 2; fi
if [ -e .TRGT_WALLY_NOT_AUTOLOGIN.token ]; then ../.dontremove/trgt/t_wallet_reverify.sh; fi
if [ -e .pfile_fail_fix.token ]; then ../.dontremove/trgt/trgt_check_pandsp.sh; fi
if [ -e .CNTRL_FAIL_RESTORE.token ]; then ../.dontremove/trgt/trgt_cntfile_restore.sh; fi
if [ -e .RMAN_REST_FAIL.token ]; then
	echo "PREVIOUS RESTORE FAILED, IF IT'S SMALL ISSUE MAY BE FIXABLE"
	echo "ONCE YOU'VE DONE CHANGES, HIT Y TO RUN AGAIN AND WE'LL SEE [Y/N]"
	read input
	if [[ $input == "Y" || $input == "y" ]]; then
		echo "OKAY RUNNING AGAIN"
		../.dontremove/trgt/trgt_REAL_restore.sh
	fi
fi
		

# COPYING IMPORTANT FILES FROM NFS TO DBS FOLDER
if [ ! -e .NAS_TRGT_CHECK.token ]; then ../.dontremove/trgt/trgt_pw_pfile_nas_copy.sh; fi

# COPYING WALLET FROM NAS
if [ ! -e .TRGT_WALLY_IS_OA.token ]; then ../.dontremove/trgt/trgt_wallet_add.sh; fi

# CHECK DB DOWN
if [ ! -e .PFP_NO_DBD_CHECK.token ]; then ../.dontremove/trgt/trgt_db_down.sh; else echo "DB IDLE CHECK NOT NEEDED"; fi

# CHECK SPFILE / PFILE WORKS
if [ ! -e .PFP_NO_DBD_CHECK.token ]; then ../.dontremove/trgt/trgt_check_pandsp.sh; fi

# MAKING SURE DB IS NOMOUNT
if [ ! -e .CNTRL_PASS_RESTORE.token ]; then ../.dontremove/trgt/trg_check_up_nomount.sh; fi

# NOW CHECK PARAMS
../.dontremove/trgt/trgt_param_check.sh

# CHECK AUTOLOGIN
if [ ! -e .TRGT_WALLY_IS_OA.token ]; then  ../.dontremove/trgt/trgt_check_autologin.sh; fi


# CONTROL FILE RESTORE
if [ ! -e .CNTRL_PASS_RESTORE.token ]; then ../.dontremove/trgt/trgt_cntfile_restore.sh; fi

# CHECKING IF DB IS MOUNTED POST CONTROLFILE
if [ -e .CNTRL_PASS_RESTORE.token ]; then ../.dontremove/trgt/trgt_check_mounted.sh; fi


# ADDING ONLINE REDO LOG CONVERTS
if [ ! -e .ONLINELOG.token ]; then
       if [ -e .DBISMOUNTED.token ]; then
               ../.dontremove/trgt/trg_add_online_logs.sh
       else
               ../.dontremove/trgt/trgt_check_mounted.sh
               ../.dontremove/trgt/trg_add_online_logs.sh
       fi
fi


# CHECKING RESTORE BACKUP PIECES
if [ -e .ONLINELOG.token ]; then
	if [ ! -e .RMAN_PRE_RESTORE_GOOD.token ]; then ../.dontremove/trgt/trgt_CHECK_restore.sh; fi
fi

# ACTUAL RESTORE
if [ -e .RMAN_PRE_RESTORE_GOOD.token ]; then
	if [ ! -e .RESTORE_IS_PASS.token ]; then ../.dontremove/trgt/trgt_REAL_restore.sh; fi
fi

# MOVE SPFILE TO ASM
if [ -e .RESTORE_IS_PASS.token ]; then
	if [ ! -e .PFILE_2_ASM_GOOD.token ]; then ../.dontremove/trgt/trgt_move_sp_2ASM.sh; fi
fi

# FINAL RECO
if [ -e .PFILE_2_ASM_GOOD.token ]; then
	if [ ! -e .DB_RECO_DONE.token ]; then ../.dontremove/trgt/trgt_REAL_reco.sh; fi
fi

if [ -e .DB_RECO_DONE.token ]; then
	if [ ! -e .DB_RECO_RESETLOGS.token ]; then ../.dontremove/trgt/trgt_open_resetlogs.sh; fi
fi

echo ===============================================
echo "ALL DONE!"
echo ===============================================
echo ===============================================
echo "OVERALL LOG -: " ${log_file}
echo ===============================================
echo "FINAL SCRIPT 1 COMPLETION TIME -> "$(date -u)

