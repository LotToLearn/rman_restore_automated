#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.

# BREAKS MAINSCRIPT IF SUB FAILS, DONT COMMENT OR BAD THINGS HAPPEN
set -e

# DEBUG COMMENT OUT IF NOT DEBUGGING
set -o pipefail

# MEGA DEBUG COMMENT OUT IF NOT DEBUGGING
#set -xv


# CHECKING FOR WRITE PERMISSIONS
echo RUNNING WRITE TO FOLDER PERMISSION TEST FOR TOKENS
if touch .PASS.TOKEN 2> /dev/null; then
        echo "WRITE PERMISSION OK"
        rm .PASS.TOKEN
else
        echo "NO WRITE PERMISSION"
        echo "TRY CHMOD -R 777 WHOLE FOLDER FROM SOURCE"
        exit 22
fi

if [ -e .need_cleanup.token ]; then echo "YOU HAVEN'T RAN CLEANUP.sh FROM A PREVIOUS ATTEMPT, RUN IT!"; exit 2; fi

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M)


echo
echo ==============================================================
echo VERIFYING VARIABLES.TXT EXISTS
echo ==============================================================
echo


if [ -f "variables.txt" ]; then
        echo "variables.txt exists, sourcing"
        source "variables.txt"
else
        echo "Error: variables.txt doesn't exist!"
        echo "Copying variables.template to variable.txt"
        cp ../.dontremove/template.variables.txt variables.txt
        chmod 777 variables.txt
        echo "Please fill out, exiting..."
        exit 2;
fi

if [[ ! -e ${NFS} ]]; then
        mkdir -m 777 ${NFS}
fi

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/


#  DIR CHECK
../.dontremove/src/dir_check.sh

export log_file=${LOGS_DIR}RMAN_OVERALL_LOG${DATE}.log
exec > >(tee -a ${log_file} )
exec 2> >(tee -a ${log_file} >&2)
echo "Spooling log to -: ${log_file}"


echo "SCRIPT 1 SCRIPT START TIME -> "$(date -u)

# Check DB UP
../.dontremove/src/src_db_up.sh

# Check SID, UNQ, BLOCK, COMPAT
../.dontremove/src/src_sid_unq_check.sh

# CHECK IF DB IN ARCHIVELOG MODE
../.dontremove/src/src_arch.sh

echo ==============================================================
echo LISTING VARIABLES, TAKE 10 SECONDS CHECK. CRTL + C TO !!KILL!! 
echo ==============================================================
echo

echo USING FOLLOWING VARIABLES -:
cat variables.txt
#sleep 10

# CREATE RMAN CHANNELS FOR BACKUP SYNTAX
../.dontremove/src/channel_create.sh

# INIT COPY TO NFS
../.dontremove/src/init_copy.sh

# PASSWORD COPY TO NFS
../.dontremove/src/password_copy.sh

echo $IMPORTANT_DIR
# WALLET TO NFS
../.dontremove/src/wallet_nfs.sh
export IMPORTANT_DIR=${NFS}IMPORTANT/

# ONLINE LOG NEWNAME
../.dontremove/src/onlinelog_convert.sh

# ORA FOR TARGET
../.dontremove/src/create_tgt_ora.sh

find ${IMPORTANT_DIR} -type f -name "*" -exec chmod 777 {} \;
find ${LOGS_DIR} -type f -name "*" -exec chmod 777 {} \;
find ${BKP_DIR} -type f -name "*" -exec chmod 777 {} \;
echo
echo ===============================================
echo "Script completed"
if [ -e .wallet_fail.token ]; then
	echo "NO WALLET FOUND"
        echo "YOU'LL NEED TO COPY WALLET CONTENTS"
        echo "PLEASE COPY TO ${IMPORTANT_DIR}${SOURCEUNQ}/"
        echo "CHECK SQLNET.ORA FOR WALLET LOCATION!!!"
fi

echo REVIEW THESE -:
echo ${IMPORTANT_DIR}init${TARGETDB}.ora
echo ===============================================
echo "RELEVANT LOGS -:"
echo ===============================================
echo ${IMPORTANT_DIR}online_newname.sql
echo ${IMPORTANT_DIR}target.rman
echo ${IMPORTANT_DIR}source.rman
echo ${IMPORTANT_DIR}init${TARGETDB}.ora
echo ===============================================
echo ===============================================
echo "OVERALL LOG -: " ${log_file}
echo ===============================================
echo "FINAL SCRIPT 1 COMPLETION TIME -> "$(date -u)
touch .rman_pre.token
