#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.

# BREAKS MAINSCRIPT IF SUB FAILS, DONT COMMENT OR BAD THINGS HAPPEN
set -e

# DEBUG COMMENT OUT IF NOT DEBUGGING
set -o pipefail

# MEGA DEBUG COMMENT OUT IF NOT DEBUGGING
#set -xv


# CHECKING FOR WRITE PERMISSIONS
echo RUNNING WRITE TO FOLDER PERMISSION TEST FOR TOKENS
if touch .PASS.TOKEN 2> /dev/null; then
        echo "WRITE PERMISSION OK"
        rm .PASS.TOKEN
else
        echo "NO WRITE PERMISSION"
        echo "TRY CHMOD -R 777 WHOLE FOLDER FROM SOURCE"
        exit 22
fi


if [ ! -e .rman_pre.token ]; then echo "SCRIPT EXITING TOKEN MISSING, PLEASE RUN rman_pre.sh FIRST!"; exit 2; fi

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M)


# checking for variables.txt
if [ -f "variables.txt" ]; then
        echo "variables.txt exists, sourcing"
        source "variables.txt"
else
        echo "Error: variables.txt doesn't exist!"
        echo "Copying variables.template to variable.txt"
        cp ../.dontremove/template.variables.txt variables.txt
        chmod 777 variables.txt
        echo "Please fill out, exiting..."
        exit 2;
fi

export LOGS_DIR=${NFS}LOGS/
export log_file=${LOGS_DIR}RMAN_SRC_BACKUP_OVERALL${DATE}.log
exec > >(tee -a ${log_file} )
exec 2> >(tee -a ${log_file} >&2)
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/

# SID, UNQ CHECK
../.dontremove/src/src_checks_prebkp.sh

# ARCH MODE CHECK
../.dontremove/src/src_2_arch_check.sh

# GRAB SCN PRE, LIST ARCH
source ../.dontremove/src/src_grab_scn_seq.sh
echo
echo ===================================
echo "PRE BACKUP SCN = ${B_SCN}"

# SHOW CONFIG, OUTPUT LOG
../.dontremove/src/rman_list_config.sh


# RMAN FULL BACKUP COMPRESSED ENC NO CONTROL FILE
time ../.dontremove/src/src_full_bak_compressed.sh

# POST SCN TO STORE
source ../.dontremove/src/src_postbkp_scn.sh

# CONTROL FILE BACKUP POST BACKUP
time ../.dontremove/src/src_bkp_ctrl_postbk.sh

# ORA SQLs
source ../.dontremove/src/src_ora_grab.sh

find ${BKP_DIR} -type f -name "*" -exec chmod 777 {} \;
find ${IMPORTANT_DIR} -type f -name "*" -exec chmod 777 {} \;
find ${LOGS_DIR} -type f -name "*" -exec chmod 777 {} \;


sleep 1
echo ===============================================
echo "Script completed"
echo "RELEVANT LOGS -:"
echo ===============================================
echo ${LOGS_DIR}RMAN_BACKUP_CONFIG_${DATE}.log 
echo ${LOGS_DIR}RMAN_FULLBKP_${DATE}.log
echo ${LOGS_DIR}RMAN_CONTROLFILE_OUTPUT_${DATE}.log
echo ${IMPORTANT_DIR}grabbed_variables.txt 
echo ===============================================
echo "FINAL SCRIPT COMPLETION TIME IS $(date -u)"
echo "Overall log spooled to ${log_file}"
touch .rman_bak_done.token
