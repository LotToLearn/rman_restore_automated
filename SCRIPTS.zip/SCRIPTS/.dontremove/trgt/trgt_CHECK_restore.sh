#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/
source "${IMPORTANT_DIR}grabbed_variables.txt"


echo
echo =========================================================================================================
echo "RUNNING RESTORE !!!PREVIEW!!! JUST CHECKING BACKUP PIECES!"
echo =========================================================================================================
echo


rman target / << EOF | tee ${LOGS_DIR}RMAN_DB_REST_CHECK_${DATE}.log
restore database preview;
exit
EOF


CHECK_REST_PREV_FAIL=$(grep -E '(ORA-.*)|(RMAN-.*)' ${LOGS_DIR}RMAN_DB_REST_CHECK_${DATE}.log | wc -l)
if [ ${CHECK_REST_PREV_FAIL} != 0 ]; then
        echo "RMAN FULL RESTORE FAILED!"
        echo "PLEASE DOUBLE CHECK EVERYTHING AND TRY AGAIN!"
	touch .RMAN_PRE_REST_FAIL.token
        exit 10
fi

touch .RMAN_PRE_RESTORE_GOOD.token









sleep 1

