#!/bin/bash


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/


echo
echo ==============================================================
echo RECHECKING WALLET IS AUTOLOGIN
echo ==============================================================
echo

RE_AUTO_LOGIN=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
spool ${LOGS_DIR}wally_chk_trgt_RE.txt
set serveroutput on
set heading off
set feedback off
select * from v\$encryption_wallet;
spool off
exit;
EOF
)

RESEDSUCKS=$(cat ${LOGS_DIR}wally_chk_trgt_RE.txt | sed "s/SINGLE.*//g" | sed "s/FILE//g" | sed "s/1//g")
echo $RESEDSUCKS > ${LOGS_DIR}wally_chk_trgt_RE.txt

cat ${LOGS_DIR}wally_chk_trgt_RE.txt

TRG_WALLY_RE=$( grep -o AUTOLOGIN ${LOGS_DIR}wally_chk_trgt_RE.txt | wc -l )
if [ ${TRG_WALLY_RE} != 1 ]; then
        echo "WALLET NOT OPEN AUTOLOGIN"
        echo "PLEASE DOUBLE CHECK WALLET AND FIX ISSUES"
        echo "QUERY select * from v\$encryption_wallet;"
        touch .TRGT_WALLY_NOT_AUTOLOGIN.token
        exit 12
else
	echo "WALLET IS OPEN AUTOLOGIN NOW, CONTINUING"
	rm .TRGT_WALLY_NOT_AUTOLOGIN.token
	touch .TRGT_WALLY_IS_OA.token
fi

sleep 1

