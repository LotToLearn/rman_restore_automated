#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/

source "${IMPORTANT_DIR}grabbed_variables.txt"

echo
echo =========================================================================================================
echo "CROSS CHECKING PARAMETERS FROM SOURCE"
echo =========================================================================================================
echo

TRGT_DBCOMPAT=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from v\$parameter where name = 'compatible';
exit;
EOF
)

TRGT_PDBPLUG=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from v\$parameter where name = 'enable_pluggable_database';
exit;
EOF
)


TRGT_BLOCK=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from v\$parameter where name='db_block_size';
exit;
EOF
)

TRGT_VTZ=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select to_char(version) from v\$timezone_file;
exit;
EOF
)

echo =================
echo TARGET PARAMS
echo =================
echo "compatible = ${TRGT_DBCOMPAT}"
echo "enable_pluggable_database = ${TRGT_PDBPLUG}"
echo "db_block_size = ${TRGT_BLOCK}"
echo "timezone_file = ${TRGT_VTZ}"
echo
echo =================
echo SOURCE PARAMS
echo =================
echo "compatible = ${DBCOMPAT}"
echo "enable_pluggable_database = ${PDBPLUG}"
echo "db_block_size = ${SRCBLOCK}"
echo "timezone_file = ${SRC_VTZ}"

if [[ "${TRGT_DBCOMPAT}" != "${DBCOMPAT}" || "${TRGT_PDBPLUG}" != "${PDBPLUG}" || "${TRGT_BLOCK}" != "${SRCBLOCK}" || "${TRGT_VTZ}" != "${SRC_VTZ}" ]]; then
	echo "VARIABLES DONT MATCH, REFER TO ABOVE"
else
	echo "PARAMETERS MATCH"
fi

echo

sleep 1

