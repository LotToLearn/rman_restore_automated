#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/


echo
echo =========================================================================================================
echo "CHECKING DATABASE IS IN NOMOUNT"
echo =========================================================================================================
echo


echo > ${LOGS_DIR}TRGT_ISNOMOUNT.log
sqlplus -s / as sysdba << EOF
spool ${LOGS_DIR}TRGT_ISNOMOUNT.log
select open_mode from v\$database;
spool off
exit
EOF

if ! grep "ORA-01507" ${LOGS_DIR}TRGT_ISNOMOUNT.log 2> /dev/null; then
	echo "DATABASE ISN'T IN NOMOUNT!"
	echo "RUN SCRIPT 3 AGAIN TO STARTUP NOMOUNT WITH PFILE!"
	touch .pfile_fail_fix.token
	exit
fi
sleep 1

