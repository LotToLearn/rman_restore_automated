#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/
source "${IMPORTANT_DIR}grabbed_variables.txt"



echo
echo =========================================================================================================
echo "RUNNING FULL DATABASE RESTORE!!!!"
echo =========================================================================================================
echo

if rm .RMAN_REST_FAIL.token 2> /dev/null; then echo "COMING OFF A PREVIOUS RESTORE FAIL!! !!!!!EXPERIMENTAL!!!!!"; fi

#set until scn ${A_SCN};
rman target / << EOF | tee ${LOGS_DIR}RMAN_DB_RESTORE_${DATE}.log
run
{
set until scn ${A_SCN};
@${IMPORTANT_DIR}target.rman
SET NEWNAME FOR DATABASE TO '${TARGETDATA}';
RESTORE DATABASE;
switch datafile all;
switch tempfile all;
}
exit
EOF


CHECK_RMAN_RESTORE_FAIL=$(grep -E '(ORA-.*)|(RMAN-.*)' ${LOGS_DIR}RMAN_DB_RESTORE_${DATE}.log | wc -l)
if [ ${CHECK_RMAN_RESTORE_FAIL} != 0 ]; then
        echo "RMAN FULL RESTORE FAILED!"
        echo "PLEASE DOUBLE CHECK EVERYTHING AND TRY AGAIN!"
	touch .RMAN_REST_FAIL.token
        exit 10
fi




touch .RESTORE_IS_PASS.token





sleep 1

