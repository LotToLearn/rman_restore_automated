#!/bin/bash


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/


echo
echo =========================================================================================================
echo "CHECKING IF ORACLE DATABASE IS DOWN"
echo =========================================================================================================
echo

CHECK_DB_DOWN=$( ps -ef|grep ${ORACLE_SID}|grep pmon|wc -l)
if [ $CHECK_DB_DOWN = 0 ]; then
        echo "ORACLE DATABASE IS IN IDLE STATE, CONTINUING"
else
        echo "ORACLE DATABASE IS NOT IDLE!!!!"
        echo "MAKE SURE THE DATABASE IS EMPTY, AND ASM IS CLEAN"
        echo "THEN SHUT IT DOWN"
        echo "EXITING!!!"
        exit 1
fi


sleep 1

