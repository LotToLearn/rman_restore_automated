#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/

echo
echo =========================================================================================================
echo "MOVING SPFILE TO ASM"
echo =========================================================================================================
echo

# FIRST GRAB U01 CURRENT SPFILE
DBS_SP_LOC=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from v\$parameter where name ='spfile';
exit
EOF
)

echo "GRABBING DBS ASM TO REMOVE AFTER ADDING TO ASM"
sleep 1
if [ ! -f "${DBS_SP_LOC}" ]; then
        echo "SPFILE PARAMETER WASN'T WORKING... MANUALLY DO IT"
        echo "create pfile='${IMPORTANT_DIR}NOTNEEDED.ora' from spfile;"
        echo "create spfile='${TARGETDATA}/${TARGETUNQ}/PARAMETERFILE/spfile${TARGETDB}.ora' from pfile='${IMPORTANT_DIR}NOTNEEDED.ora';"
        echo "shut immediate"
        echo "startup nomount"
        echo "SCRIPT WONT CONTINUE UNTIL SPFILE IS IN ASM DATA!!!"
        touch .ASM_SPFILE_FAILED.token
        exit 3
fi

echo > ${LOGS_DIR}MOVE_SPFILE_2_ASM.log
sqlplus -s / as sysdba << EOF
spool ${LOGS_DIR}MOVE_SPFILE_2_ASM.log
create pfile='${IMPORTANT_DIR}NOTNEEDED.ora' from spfile;
create spfile='${TARGETDATA}/${TARGETUNQ}/PARAMETERFILE/spfile${TARGETDB}.ora' from pfile='${IMPORTANT_DIR}NOTNEEDED.ora';
!rm ${DBS_SP_LOC} 
shut immediate
startup mount
spool off
exit
EOF


CHECK_ASM_ERROR=$(grep -E '(ORA-.*)|(LRM-.*)' ${LOGS_DIR}MOVE_SPFILE_2_ASM.log | grep -v "ORA-01109" | wc -l)
if [ $CHECK_ASM_ERROR = 0 ]; then
        echo "NO ERRORS"
        touch .PFILE_2_ASM_GOOD.token
else
        echo "ERRORS"
	echo "MANUALLY ADD SPFILE TO ASM!!!"
        touch .PFILE_2_ASM_BAD.token
        exit 10
fi

sleep 1
