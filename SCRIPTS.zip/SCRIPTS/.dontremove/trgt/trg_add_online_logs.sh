#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/


echo
echo =========================================================================================================
echo "CONVERTING ONLINE REDO LOGS"
echo =========================================================================================================
echo


sqlplus -s / as sysdba << EOF
start ${IMPORTANT_DIR}online_newname.sql
exit
EOF

touch .ONLINELOG.token

sleep 1

