#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/
source "${IMPORTANT_DIR}grabbed_variables.txt"

echo
echo =========================================================================================================
echo "RECOVERING DATABASE"
echo =========================================================================================================
echo

rman target / << EOF | tee ${LOGS_DIR}RMAN_DB_RECOVER_${DATE}.log
run
{
SET NOCFAU;
@${IMPORTANT_DIR}target.rman
CROSSCHECK BACKUP OF DATABASE;
catalog start with '${BKP_DIR}' noprompt;
recover database;
}
EOF

RECO_FAIL=$(grep -E '(ORA-.*)|(RMAN-.*)' ${LOGS_DIR}RMAN_DB_RECOVER_${DATE}.log | grep -v "RMAN-00571" | grep -v "RMAN-00569" | grep -v "RMAN-03002" | grep -v RMAN-06054 | wc -l)
if [ ${RECO_FAIL} != 0 ]; then
        echo "RMAN RECOVERY FAILED!"
        echo "PLEASE DOUBLE CHECK EVERYTHING AND TRY AGAIN!"
        exit 10
fi



echo
echo =========================================================================================================
echo "THESE ARE OK, WE HAVE TO OPEN RESETLOGS IS WHY, POST RECOVERY"
echo "RMAN-06054: media recovery requesting unknown archived log"
echo "RMAN-06054: media recovery requesting unknown archived log for thread ............."
echo =========================================================================================================
echo


# TO DO
# alter database open resetlogs;
# FILTER WARNING

touch .DB_RECO_DONE.token

sleep 1

