#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/

echo
echo ==============================================================
echo COPYING WALLET FROM NAS, EXPERIMENTAL, MAY HAVE TO DO MANUALLY
echo ==============================================================
echo
touch .TRGT_WALLY_IS_OA.token
exit
if cp -r "$ORACLE_HOME/network/admin/sqlnet.ora" .DEL1 2> /dev/null; then
        sed '/ORACLE_UNQNAME/{s/\(.*ORACLE_UNQNAME\).*/\1/;q}' .DEL1 > .DEL2
        sed 's/\$ORACLE_UNQNAME//' .DEL2 > .DEL3
        cat .DEL3 | sed 's/.*=//' > .DEL4
        GRABWALLY=$(cat .DEL4)
        echo "SQLNET.ORA FOUND"
        rm .DEL*
        sleep 1
else
        echo "SQLNET.ORA NOT FOUND!"
        echo "YOU WILL NEED TO COPY WALLET CONTENTS"
        echo "PLEASE COPY TO ${IMPORTANT_DIR}/${SOURCEUNQ}/"
        echo "MANUALLY COPY WALLET FROM NFS!"
        touch .TRGT_wallet_fail.token
fi

echo "MOVING FROM NAS NOW"
sleep 1
if [ -d ${GRABWALLY}${TARGETUNQ} ]; then
	if [ ! -d ${GRABWALLY}${TARGETUNQ}/BAK ]; then
		mkdir -m 777 ${GRABWALLY}${TARGETUNQ}/BAK	
		echo "MAKING DIR ${GRABWALLY}${TARGETUNQ}/BAK AND MOVING OLD WALLET"
		mv ${GRABWALLY}${TARGETUNQ}/* ${GRABWALLY}${TARGETUNQ}/BAK 2> /dev/null
	else
		mv ${GRABWALLY}${TARGETUNQ}/* ${GRABWALLY}${TARGETUNQ}/BAK 2> /dev/null
	fi
fi

if cp ${IMPORTANT_DIR}${SOURCEUNQ}/* ${GRABWALLY}${TARGETUNQ}/ 2> /dev/null; then
        echo "WALLET FOUND, COPYING TO ${GRABWALLY}${TARGETUNQ}/"
        ls -ltr ${GRABWALLY}${TARGETUNQ}/
        sleep 1
else
        echo "NO WALLET FOUND"
        echo "YOU WILL NEED TO COPY WALLET CONTENTS"
        echo "PLEASE COPY TO ${GRABWALLY}${TARGETUNQ}/"
        echo "MANUALLY COPY WALLET!"
        touch .TRGT_wallet_fail.token
fi

touch .TRGT_WALLY_IS_OA.token

sleep 1

