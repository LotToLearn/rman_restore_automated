#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/

echo
echo =========================================================================================================
echo "OPENING DATABASE AND RUNNING RESET LOGS"
echo =========================================================================================================
echo



sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
alter database open resetlogs;
exit;
EOF




touch .DB_RECO_RESETLOGS.token

sleep 1

