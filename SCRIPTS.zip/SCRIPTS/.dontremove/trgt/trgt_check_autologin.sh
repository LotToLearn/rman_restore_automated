#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/

IS_AUTO_LOGIN=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
spool ${LOGS_DIR}wally_chk_trgt_OA.txt
set serveroutput on
set heading off
set feedback off
select * from v\$encryption_wallet;
spool off
exit;
EOF
)
SEDSUCKS=$(cat ${LOGS_DIR}wally_chk_trgt_OA.txt | sed "s/SINGLE.*//g" | sed "s/FILE//g" | sed "s/1//g")
echo $SEDSUCKS > ${LOGS_DIR}wally_chk_trgt_OA.txt

cat ${LOGS_DIR}wally_chk_trgt_OA.txt

TRG_WALLY_PF=$( grep -o AUTOLOGIN ${LOGS_DIR}wally_chk_trgt_OA.txt | wc -l )
if [ ${TRG_WALLY_PF} != 1 ]; then
	echo "WALLET NOT OPEN AUTOLOGIN"
	echo "PLEASE DOUBLE CHECK WALLET AND FIX ISSUES"
	echo "QUERY select * from v\$encryption_wallet;"
	touch .TRGT_WALLY_NOT_AUTOLOGIN.token
	echo "FIX AND RE RUN MAIN 3 SCRIPT"
	exit 12
fi

touch .TRGT_WALLY_IS_OA.token

sleep 1

