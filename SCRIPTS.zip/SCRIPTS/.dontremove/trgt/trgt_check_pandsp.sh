#!/bin/bash


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/


echo
echo =========================================================================================================
echo "CHECKING IF OUR DATABASE CAN START WITH PFILE AND CREATE AN SPFILE"
echo =========================================================================================================
echo

if rm .pfile_fail_fix.token 2> /dev/null; then echo "COMING OFF PREVIOUS PFILE FAIL"; fi

echo > ${LOGS_DIR}TRGT_PFILE_STARTUP.log
sqlplus -s / as sysdba << EOF 
spool ${LOGS_DIR}TRGT_PFILE_STARTUP.log
startup nomount pfile='$ORACLE_HOME/dbs/init${TARGETDB}.ora';
create spfile='$ORACLE_HOME/dbs/spfile${TARGETDB}.ora' from pfile='$ORACLE_HOME/dbs/init${TARGETDB}.ora';
shutdown immediate
startup nomount
show parameter spfile;
spool off
exit
EOF

CHECK_PFILE_ERROR=$(grep -E '(ORA-.*)|(LRM-.*)' ${LOGS_DIR}TRGT_PFILE_STARTUP.log | grep -v "ORA-01507" | wc -l)
if [ $CHECK_PFILE_ERROR = 0 ]; then
	echo "NO ERROR"S
	touch .PFP_NO_DBD_CHECK.token
else
	echo "ERRORS"
	echo "USUALLY CHECK PARAMETERS HAVE ' AROUND THEM FOR WORDS"
	echo "CHECK CONVERT PARAMETERS, ASM DIRECTORIES CORRECT, ETC..."
	echo "MAKE SURE RECO / DATA IS GOOD"
	echo "PLEASE DOUBLE CHECK DIRECTORIES AS WELL"
	echo "startup nomount pfile='$ORACLE_HOME/dbs/init${TARGETDB}.ora';"
	echo "create spfile='$ORACLE_HOME/dbs/spfile${TARGETDB}.ora' from pfile='$ORACLE_HOME/dbs/init${TARGETDB}.ora';"
	echo "SHUT DOWN ONCE FIX PFILE, SCRIPT WILL RUN THROUGH AGAIN"
	touch .pfile_fail_fix.token
	exit 10
fi

sleep 1
