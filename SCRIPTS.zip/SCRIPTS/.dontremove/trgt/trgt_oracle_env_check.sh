#!/bin/bash


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/


echo
echo ==============================================================
echo VERIFYING ORACLE_SID AND ORACLE_UNQNAME!
echo ==============================================================
echo



if [ $TARGETDB = $ORACLE_SID ]; then
        echo "$TARGETDB MATCHES $ORACLE_SID"
else
        echo "USER SET VARIABLE $TARGETDB DOES NOT MATCH DATABASE VARIABLE $ORACLE_SID"
        exit 3
fi

if [ $TARGETUNQ = $ORACLE_UNQNAME ]; then
        echo "USER SET VARIABLE $TARGETUNQ MATCHES DATABASE VARIABLE $ORACLE_UNQNAME"
else
        echo "USER SET VARIABLE $TARGETUNQ DOES NOT MATCH DATABASE VARIABLE $ORACLE_UNQNAME"
        exit 3
fi





sleep 1

