#!/bin/bash


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/


echo
echo =========================================================================================================
echo "COPYING FILES FROM NFS TO THIS SERVER"
echo =========================================================================================================
echo
# PASSWORD FILE INFO
# CHECKING FOR LEGACY
if [ -f "$ORACLE_HOME/dbs/orapw${TARGETDB}" ]; then
        if [ ! -f "OLD_orapw${TARGETDB}"* ]; then
                mv $ORACLE_HOME/dbs/orapw${TARGETDB} $ORACLE_HOME/dbs/OLD_orapw${TARGETDB}
                echo "Moved orapw${TARGETDB} to OLD_orapw${TARGETDB}"
        fi
fi

# COPYING FROM NFS
if [ -f "${IMPORTANT_DIR}orapw${TARGETDB}" ]; then
        cp -p ${IMPORTANT_DIR}orapw${TARGETDB} $ORACLE_HOME/dbs/orapw${TARGETDB}
        echo "COPYING orapw${TARGETDB} from NFS"
else
        echo "CANNOT FIND ORA PASSWORD FILE!"
        echo "SEARCHED FOR ${IMPORTANT_DIR}orapw${TARGETDB}"
        echo "PLEASE MANUALLY ADD"
        exit 9
fi

if [ -f "$ORACLE_HOME/dbs/spfile${TARGETDB}.ora" ]; then
        if [ ! -f "$ORACLE_HOME/dbs/OLD_spfile${TARGETDB}.ora"* ]; then
        echo "OLD SPFILE MOVED TO OLD_spfile${TARGETDB}.ora"
        mv $ORACLE_HOME/dbs/spfile${TARGETDB}.ora $ORACLE_HOME/dbs/OLD_spfile${TARGETDB}.ora
        fi
fi

# COPYING OUR INIT.ORA FROM NFS

# REMOVING LEGACY IF ITS THERE
if [ -f "$ORACLE_HOME/dbs/init${TARGETDB}.ora" ]; then
        if [ ! -f "$ORACLE_HOME/dbs/OLD_init${TARGETDB}.ora"* ]; then
                mv $ORACLE_HOME/dbs/init${TARGETDB}.ora $ORACLE_HOME/dbs/OLD_init${TARGETDB}.ora
                echo "OLD INIT FILE MOVED TO OLD_init${TARGETDB}.ora"
        fi
fi

# COPYING FROM NAS
if [ -f "${IMPORTANT_DIR}init${TARGETDB}.ora" ]; then
        cp -p ${IMPORTANT_DIR}init${TARGETDB}.ora $ORACLE_HOME/dbs/init${TARGETDB}.ora
        echo "COPYING init${TARGETDB}.ora from NFS"
else
        echo "CANNOT FIND INIT FILE!"
        echo "SEARCHED FOR ${IMPORTANT_DIR}init${TARGETDB}.ora"
        echo "PLEASE MANUALLY ADD"
        exit 1
fi


touch .NAS_TRGT_CHECK.token


sleep 1

