#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/

echo
echo =========================================================================================================
echo "CHECKING IF DATABASE IS MOUNTED POST CONTROLFILE RESTORE"
echo =========================================================================================================
echo



echo > ${LOGS_DIR}TRGT_ISMOUNT.log
sqlplus -s / as sysdba << EOF
set head off
set pagesize 0
spool ${LOGS_DIR}TRGT_ISMOUNT.log
select open_mode from v\$database;
spool off
exit
EOF

if grep -q "MOUNTED" ${LOGS_DIR}TRGT_ISMOUNT.log; then
	touch .DBISMOUNTED.token
else
	echo "DATABASE IS NOT MOUNTED"
	echo "CHECK IF CONTROLFILE RESTORE IS SUCCESSFUL"
	touch .DBISNOTMOUNTED.token
	exit 13
fi


sleep 1

