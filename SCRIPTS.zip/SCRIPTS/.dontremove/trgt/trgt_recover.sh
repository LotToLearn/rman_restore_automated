#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/
export RMAN_FRMT=${NFS}BACKUP
source "${IMPORTANT_DIR}grabbed_variables.txt"


#rman target / << EOF | tee ${LOGS_DIR}RMAN_TRGT_DB_RECO_${DATE}.log
#set encryption on;
#run
#{
#SET NOCFAU;
#@${IMPORTANT_DIR}target.rman
#CROSSCHECK BACKUP OF DATABASE;
#catalog start with '${RMAN_FRMT}' noprompt;
#recover database;
#}

RECO_FAIL=$(grep -E '(ORA-.*)|(RMAN-.*)' ${LOGS_DIR}RMAN_TRGT_DB_RECO_${DATE}.log | grep -v "RMAN-00571" | grep -v "RMAN-00569" | grep -v "RMAN-03002" | grep -v "RMAN-06054" | wc -l)
if [ ${RECO_FAIL} != 0 ]; then
        echo "RMAN RECOVERY FAILED!"
        echo "PLEASE DOUBLE CHECK EVERYTHING AND TRY AGAIN!"
        exit 10
fi
echo
echo "IF YOU SEE"
echo "RMAN-06054: media recovery requesting unknown archived log for thread 1 with sequence 8 and starting SCN of 2285571"
echo "THIS IS OK, DON'T WORRY!"









sleep 1

