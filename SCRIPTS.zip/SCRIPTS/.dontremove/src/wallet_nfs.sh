#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export BKP_DIR=${NFS}BACKUP/
echo
echo ==============================================================
echo COPYING SOURCE WALLET
echo ==============================================================
echo
export IMPORTANT_DIR=${NFS}IMPORTANT
echo $IMPORTANT_DIR
if cp -r "$ORACLE_HOME/network/admin/sqlnet.ora" .DEL1 2> /dev/null; then
        sed '/ORACLE_UNQNAME/{s/\(.*ORACLE_UNQNAME\).*/\1/;q}' .DEL1 > .DEL2
        sed 's/\$ORACLE_UNQNAME//' .DEL2 > .DEL3
        cat .DEL3 | sed 's/.*=//' > .DEL4
        GRABWALLY=$(cat .DEL4)
        echo "SQLNET.ORA FOUND"
        rm .DEL*
        sleep 1
else
        echo "SQLNET.ORA NOT FOUND!"
        echo "YOU WILL NEED TO COPY WALLET CONTENTS"
        echo "PLEASE COPY TO ${IMPORTANT_DIR}/${SOURCEUNQ}/"
        echo "MANUALLY COPY WALLET!"
        touch .wallet_fail.token
fi
if cp -r "${GRABWALLY}${SOURCEUNQ}/" ${IMPORTANT_DIR}/${SOURCEUNQ}/ 2> /dev/null; then
        echo "WALLET FOUND, COPYING TO ${IMPORTANT_DIR}/${SOURCEUNQ}/"
        ls -ltr ${IMPORTANT_DIR}/${SOURCEUNQ}/
        sleep 1
else
        echo "NO WALLET FOUND"
        echo "YOU WILL NEED TO COPY WALLET CONTENTS"
        echo "PLEASE COPY TO ${IMPORTANT_DIR}/${SOURCEUNQ}/"
        echo "MANUALLY COPY WALLET!"
        touch .wallet_fail.token
fi
sleep 2
