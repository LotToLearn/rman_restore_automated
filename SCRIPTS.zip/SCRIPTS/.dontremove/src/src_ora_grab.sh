#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/

echo
echo =========================================================================================================
echo "GRABBING SOME VARIABLES FOR RESTORE"
echo =========================================================================================================
echo

# GRABBING COMPATIBLE VERSION TO CROSSCHECK LATER
DBCOMPAT=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from v\$parameter where name = 'compatible';
exit;
EOF
)

# GRABBING enable_pluggable_database TO CROSSCHECK LATER
PDBPLUG=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from v\$parameter where name = 'enable_pluggable_database';
exit;
EOF
)

# GRABBING AFTER BACKUP SCN
A_SCN=$(sqlplus -s "/ as sysdba" << EOF
set head off
set pagesize 0
select to_char(current_scn) from v\$database;
exit
EOF
)


# GRABBING db_block_size TO CROSSCHECK LATER
SRC_BLOCK=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from v\$parameter where name='db_block_size';
exit;
EOF
)

# GRABBING DATABASE NAME TO CROSSCHECK LATER
DBNAME=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select name from v\$database;
exit;
EOF
)

# GRABBING DBID TO CROSSCHECK LATER
DBID=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select DBID from v\$database;
exit;
EOF
)

# GRABBING NLS_CHARACTERSET TO CROSSCHECK LATER
SRC_CHAR=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from NLS_DATABASE_PARAMETERS where PARAMETER='NLS_CHARACTERSET';
exit;
EOF
)

# GRABBING dbtimezone TO CROSSCHECK LATER
SRC_DBTZ=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select dbtimezone from dual
exit;
EOF
)

# GRABBING TIMEZONE VERSION TO CROSSCHECK LATER
SRC_VTZ=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select to_char(version) from v\$timezone_file;
exit;
EOF
)


echo "B_SCN=${B_SCN}" >  ${IMPORTANT_DIR}grabbed_variables.txt
echo "A_SCN=${A_SCN}" >>  ${IMPORTANT_DIR}grabbed_variables.txt
echo "SRC_VTZ=${SRC_VTZ}" >>  ${IMPORTANT_DIR}grabbed_variables.txt
echo "SRC_CHAR=${SRC_CHAR}" >>  ${IMPORTANT_DIR}grabbed_variables.txt
echo "SRC_DBTZ=${SRC_DBTZ}" >>  ${IMPORTANT_DIR}grabbed_variables.txt
echo "DBID=${DBID}" >>  ${IMPORTANT_DIR}grabbed_variables.txt
echo "DBNAME=${DBNAME}" >>  ${IMPORTANT_DIR}grabbed_variables.txt
echo "DBCOMPAT=${DBCOMPAT}" >>  ${IMPORTANT_DIR}grabbed_variables.txt
echo "PDBPLUG=${PDBPLUG}" >>  ${IMPORTANT_DIR}grabbed_variables.txt
echo "SRCBLOCK=${SRC_BLOCK}" >>  ${IMPORTANT_DIR}grabbed_variables.txt

echo "VARIABLES GRABBED!"
cat ${IMPORTANT_DIR}grabbed_variables.txt

sleep 1
