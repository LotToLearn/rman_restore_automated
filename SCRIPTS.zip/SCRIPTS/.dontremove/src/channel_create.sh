#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/

echo
echo ==============================================================
echo ALLOCATING RMAN CHANNELS BASED OF VARIABLES.TXT
echo ==============================================================
echo

for ((i=1;i<=${CHANNELS};i++))
do
echo "allocate channel c$i device type disk maxpiecesize 32g;" >> ${IMPORTANT_DIR}target.rman
echo "allocate channel c$i device type disk maxpiecesize 32g  format '${BKP_DIR}BKP_%u_%p_%c_%s_%t';" >> ${IMPORTANT_DIR}source.rman
done

echo ALLOCATION COMPLETED
sleep 2





sleep 1

