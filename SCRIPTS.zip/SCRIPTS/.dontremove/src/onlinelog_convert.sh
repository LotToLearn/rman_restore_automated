#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/
echo
echo ==============================================================
echo GRABBING ONLINE LOG NEWNAME CONVERT
echo ==============================================================
echo


sqlplus -s "/ as sysdba" << EOF
set serveroutput on
set heading off
set feedback off
set pagesize 0
set linesize 999
spool ${IMPORTANT_DIR}online_newname.sql
select 'alter database rename file '''||member||''' to ''${TARGETRECO}'';' from v\$logfile where member like '%+RECO%';
select 'alter database rename file '''||member||''' to ''${TARGETDATA}'';' from v\$logfile where member like '%+DATA%';
spool off;
EOF






sleep 1

