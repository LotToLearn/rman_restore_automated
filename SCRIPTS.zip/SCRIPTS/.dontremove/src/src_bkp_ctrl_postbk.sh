#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/
export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)


echo
echo =========================================================================================================
echo "RUNNING CONTROLFILE BACKUP"
echo =========================================================================================================
echo


rman target / << EOF | tee ${LOGS_DIR}RMAN_CONTROLFILE_OUTPUT_${DATE}.log
set encryption on;
run
{
SET NOCFAU;
allocate channel c1 device type disk;
backup as copy  current controlfile format '${IMPORTANT_DIR}control.ctl';
}
EOF


CHECK_RMAN_CONTROL_FAIL=$(grep -E '(ORA-.*)|(RMAN-.*)' ${LOGS_DIR}RMAN_CONTROLFILE_OUTPUT_${DATE}.log | wc -l)
if [ ${CHECK_RMAN_CONTROL_FAIL} != 0 ]; then
        echo "RMAN CONTROL FILE BACKUP FAILED!"
        echo "PLEASE DOUBLE CHECK EVERYTHING AND TRY AGAIN!"
        exit 10
fi


touch .src_control.token


sleep 1

