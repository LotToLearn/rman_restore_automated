#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/

echo
echo ==============================================================
echo COPYING ORA FILE TO NFS ${IMPORTANT_DIR}REF_init${TARGETDB}.ora
echo ==============================================================
echo
PF="${IMPORTANT_DIR}REF_init${TARGETDB}.ora"
sqlplus -s "/ as sysdba" << EOF
create pfile='$PF' from spfile;
EOF
echo "init${TARGETDB}.ora WAS COPIED"
echo
sleep 1

