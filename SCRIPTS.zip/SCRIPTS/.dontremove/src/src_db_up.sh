#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/



echo
echo =========================================================================================================
echo "CHECKING IF ORACLE SOURCE DATABASE IS UP"
echo =========================================================================================================
echo

CHECK_DB_DOWN=$( ps -ef|grep ${ORACLE_SID}|grep pmon|wc -l)
if [ $CHECK_DB_DOWN -ge 1 ]; then
        echo "ORACLE DATABASE IS UP, CONTINUING"
else
        echo "ORACLE DATABASE IS NOT UP!!!!"
        echo "MAKE SURE THE DATABASE IS EMPTY, AND ASM IS CLEAN"
        echo "THEN SHUT IT DOWN"
        echo "EXITING!!!"
        exit 1
fi

sleep 1

