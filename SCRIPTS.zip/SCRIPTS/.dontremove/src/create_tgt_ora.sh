#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/

echo
echo ==============================================================
echo CREATING ORA FOR TARGET!! QUERYING FOR VALUES
echo ==============================================================
echo


DBCOMPAT=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from v\$parameter where name = 'compatible';
exit;
EOF
)


RECODESTSIZE=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
set pagesize 0
select to_char(space_limit) from v\$recovery_file_dest;
exit;
EOF
)


DBFILES=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from v\$parameter where name = 'db_files';
exit;
EOF
)

UNDOGRAB=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from v\$parameter where name = 'undo_tablespace';
exit;
EOF
)

PDBPLUG=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select value from v\$parameter where name = 'enable_pluggable_database';
exit;
EOF
)


touch ${IMPORTANT_DIR}init${TARGETDB}.ora
cat << EOF >> ${IMPORTANT_DIR}init${TARGETDB}.ora
*.compatible=${DBCOMPAT}
*.sga_target=${TARGETSGA}
*.sga_max_size=${TARGETSGA}
*.pga_aggregate_target=${TARGETPGA}
*.remote_login_passwordfile='EXCLUSIVE'
*.db_name='${SOURCEDB}'
*.db_unique_name='${TARGETUNQ}'
*.audit_file_dest='${TARGETAUDIT}'
*.control_files='${TARGETDATA}/${TARGETUNQ}/controlfile/control01.ctl'
*.db_block_size=${BLOCKSIZE}
*.db_create_file_dest='${TARGETDATA}'
*.db_create_online_log_dest_1='${TARGETRECO}'
*.db_domain='${TARGETDOMAIN}'
*.log_archive_dest_1='location=USE_DB_RECOVERY_FILE_DEST'
*.db_recovery_file_dest='${TARGETRECO}'
*.db_recovery_file_dest_size=${RECODESTSIZE}
*.job_queue_processes=0
*.undo_tablespace='${UNDOGRAB}'
*.enable_pluggable_database=${PDBPLUG}
*.max_string_size=STANDARD
*.db_files=${DBFILES}
EOF

echo "USING THESE PARAMETERS FOR TARGET, PLEASE DOUBLE CHECK"
echo "${IMPORTANT_DIR}init${TARGETDB}.ora"
cat ${IMPORTANT_DIR}init${TARGETDB}.ora

echo
echo "!!! IMPORTANT FOR UNDO !!!"
echo "SCRIPT ONLY GRABS ONE UNDO, THERE MAY BE MORE!!!"
echo "DEFAULT IS ONE, BUT CUSTOMERS CAN ADD AND RAC WILL ADD MORE"
echo "SCRIPT WILL QUERY FROM SQL, BUT YOU MUST MANUALLY ADD ON !!! TARGET !!!"
echo "E.G. create undo tablespace UNDOTBS2 datafile '${TARGETDATA}/${TARGETUNQ}/datafile/UNDOTBS2.dbf size 1g;"


sqlplus -s / as sysdba << EOF
whenever sqlerror exit 3
SELECT con_id, tablespace_name
FROM   cdb_tablespaces
WHERE  tablespace_name LIKE 'UNDO%'
ORDER BY con_id;
exit;
EOF


echo "NOTE -: CHECK CON ID, IF YOU HAVE TWO UNDOTBS1 IN DIFF CON ID"
echo "YOU DON'T HAVE TO ADD ANYMORE!"

sleep 1  

