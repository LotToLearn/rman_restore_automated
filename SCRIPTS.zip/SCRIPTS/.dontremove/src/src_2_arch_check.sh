#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/



echo
echo ==============================================================
echo CHECKING IF DATABASE IS IN ARCHIVELOG MODE **IT MUST BE**
echo ==============================================================
echo

oalog=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select log_mode from v\$database;
exit;
EOF
)

if [ ${oalog} != "ARCHIVELOG" ]; then
        echo "Error: DATABASE ISN'T IN ARCHIVELOG MODE!!!"
        exit 2;
fi
echo  "DATABASE IS IN ARCHIVELOG MODE!"
touch .src_rman.token



sleep 1

