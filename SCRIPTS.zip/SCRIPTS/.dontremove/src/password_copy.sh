#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/
echo ==============================================================
echo TAKING OUR PASSWORD FILE AND COPYING IT TO NFS
echo ==============================================================
echo
cp $ORACLE_HOME/dbs/orapw${SOURCEDB} ${IMPORTANT_DIR}orapw${TARGETDB}
echo PASSWORD FILE SUCCESSFULLY COPIED TO NFS

