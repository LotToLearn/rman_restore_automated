#!/bin/bash


source "variables.txt"

export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
export DATE=$(date +%Y-%m-%d-%H-%M-%S)
export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/


echo
echo =========================================================================================================
echo "RUNNING FULL BACKUP INCLUDING ARCHIVELOGS"
echo =========================================================================================================
echo


rman target / << EOF | tee ${LOGS_DIR}RMAN_FULLBKP_${DATE}.log
set encryption on;
run
{
SET NOCFAU;
@${IMPORTANT_DIR}source.rman
sql 'alter system archive log current';
sql 'alter system checkpoint global';
BACKUP AS COMPRESSED BACKUPSET DATABASE PLUS ARCHIVELOG;
}
EOF

CHECK_RMAN_BACKUP_FAIL=$(grep -E '(ORA-.*)|(RMAN-.*)' ${LOGS_DIR}RMAN_FULLBKP_${DATE}.log | wc -l)
if [ ${CHECK_RMAN_BACKUP_FAIL} != 0 ]; then
        echo "RMAN BACKUP FAILED!"
        echo "PLEASE DOUBLE CHECK EVERYTHING AND TRY AGAIN!"
        exit 10
fi


sleep 1

