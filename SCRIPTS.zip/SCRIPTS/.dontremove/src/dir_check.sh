#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"


echo
echo ==============================================================
echo CREATEING LOGS / BACKUP / IMPORTANT DIR
echo ==============================================================
echo

export LOGS_DIR=${NFS}LOGS/
if [ -d "$LOGS_DIR" ]; then
        echo "Directory already exists, checking if empty"
        if [ ! "$(ls -A ${LOGS_DIR})" ]; then
                echo "${LOGS_DIR} IS EMPTY, CONTINUING"
        else
                echo "${LOGS_DIR} IS NOT EMPTY!"
                echo "TO AVOID ISSUES, IT SHOULD BE!"
                echo "DOUBLE CHECK, AND RUN CLEANUP.sh"
                echo "WOULD YOU LIKE TO CEALNUP NOW AND PROCEED? [Y/N]"
                read input
                if [[ $input == "Y" || $input == "y" ]]; then
                        echo "REMOVING"
                        if ls -a .*.token 1> /dev/null 2>&1; then
                                rm .*.token
                        fi
                        rm -rf ${NFS}BACKUP
                        rm -rf ${NFS}IMPORTANT
                        if [ -d "${LOGS_DIR}" ]; then
                                cp -r ${LOGS_DIR} ${NFS}BAK_LOG_${DATE}
                                rm -rf ${LOGS_DIR}
                                echo "MOVED OLD LOGS DIR TO ${NFS}BAK_LOG_${DATE}"
				sleep .7
                                chmod -R 777 ${NFS}BAK_LOG_${DATE}
                        fi
                        echo "Creating logs folder and creating .log file"
                        mkdir -m 777 ${LOGS_DIR}

                else
                        echo "EXITING, RUN CLEANUP.SH"
                        touch .need_cleanup.token
                        exit 2
                fi
        fi
else
        echo "Creating logs folder and creating .log file"
        mkdir -m 777 ${LOGS_DIR}
fi

export IMPORTANT_DIR=${NFS}IMPORTANT/
if [ -d "$IMPORTANT_DIR" ]; then
	rm -rf ${IMPORTANT_DIR}
	mkdir -m 777 ${IMPORTANT_DIR}
else
        mkdir -m 777 ${IMPORTANT_DIR}
fi

export BKP_DIR=${NFS}BACKUP/

if [ -d "$BKP_DIR" ]; then
	rm -rf ${BKP_DIR}
	mkdir -m 777 ${BKP_DIR}
else
	mkdir -m 777 ${BKP_DIR}
fi

echo

sleep 1

