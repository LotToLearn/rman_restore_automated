#!/bin/bash
# Copyright (C) 2020 NOAH HORNER (https://github.com/LotToLearn)
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.


source "variables.txt"

export LOGS_DIR=${NFS}LOGS/
export IMPORTANT_DIR=${NFS}IMPORTANT/
export BKP_DIR=${NFS}BACKUP/


echo
echo ==============================================================
echo CHECKING SOME IMPORTANT VARIABLES.TXT MATCH DATABASE
echo ==============================================================
echo

#### DBASE NAME ####
osid=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select name from v\$database;
exit;
EOF
)
if [ ${osid} != "${SOURCEDB}" ]; then
        echo "Error: Double check SOURCEDB variable!, exiting"
         exit 2;
fi

echo "ORACLE SID ${osid} DOES MATCH USER SET VARIABLE ${SOURCEDB}"
####
#### UNIQUE NAME ####
ounq=$(sqlplus -s / as sysdba << EOF | tr -d '\n'
set serveroutput on
set heading off
set feedback off
select db_unique_name from v\$database;
exit;
EOF
)
if [ ${ounq} != "${SOURCEUNQ}" ]; then
        echo "Error: Double check SOURCEUNQ variable!, exiting"
         exit 2;
fi
echo  "ORACLE UNIQUE NAME ${ounq} DOES MATCH USER SET ${SOURCEUNQ} VARIABLE!"



sleep 1

